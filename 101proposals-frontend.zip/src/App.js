import React from 'react';

function App() {
  return (
    <div className='text-center text-2xl font-bold text-blue-600 mt-20'>
      Welcome to 101PROPOSALS
    </div>
  );
}

export default App;